#include "MainWindow.h"
#include "ui_mainwindow.h"
#include <QHBoxLayout>

MainWindow::MainWindow(QWidget *parent) :
  QMainWindow(parent)
  , ui(new Ui::MainWindow)
  , mCentralWidget(new QWidget(this))
  , mFileViewerPaner(new FileViewerPane(mCentralWidget))
  , mViewer(new ViewerPane(this))
{
    ui->setupUi(this);
    QHBoxLayout* mLayout = new QHBoxLayout(mCentralWidget);
    mLayout->addWidget(mFileViewerPaner);
    mLayout->addWidget(mViewer);
    mCentralWidget->setLayout(mLayout);

    setCentralWidget(mCentralWidget);

    connect(mFileViewerPaner, &FileViewerPane::OnFilesSelectionChanged, this, &MainWindow::DoOnFilesSelectionChanged);
    connect(mViewer, &ViewerPane::OnFileLoadedCountChanged, this, &MainWindow::UpdateStatusBar);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::DoOnFilesSelectionChanged(QString const & directory, std::vector<QString> const & fileNames)
{
  mViewer->RenderFiles(directory,fileNames);
}

void MainWindow::UpdateStatusBar(QString const & inMsg)
{
  statusBar()->showMessage(inMsg);
}
