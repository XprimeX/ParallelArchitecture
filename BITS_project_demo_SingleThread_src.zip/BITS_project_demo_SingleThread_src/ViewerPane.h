#ifndef VIEWERPANE_H
#define VIEWERPANE_H

#include <QString>
#include <QTabWidget>

#include <vector>
class ViewerPane : public QTabWidget
{
Q_OBJECT
public:
  ViewerPane(QWidget * inParent);
  void RenderFiles(QString const & directory, std::vector<QString> const & fileNames);
signals:
  void OnFileLoadedCountChanged(QString const &);
private:
  std::vector<QWidget*> mTabPages;
};

#endif // VIEWERPANE_H
