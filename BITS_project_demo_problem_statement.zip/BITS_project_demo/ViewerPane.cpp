#include "ViewerPane.h"

#include <QDir>
#include <QLabel>
#include <QPixmap>
#include <QScrollArea>
#include <QVBoxLayout>

#include <chrono>
#include <QDebug>

class ImagePage : public QWidget
{
public:
  ImagePage(QWidget* inParent, QString const & imagePath)
  :
    QWidget(inParent)
  , mImageLabel(new QLabel(this))
  , mScrollArea(new QScrollArea())
  {

    mScrollArea = new QScrollArea;
    mScrollArea->setBackgroundRole(QPalette::Dark);

    mImageLabel = new QLabel();
    mImageLabel->setSizePolicy(QSizePolicy::Expanding,
                                        QSizePolicy::Expanding);
    mImageLabel->setAlignment(Qt::AlignCenter);
    //mImageLabel->setMinimumSize(400, 400);

    QVBoxLayout *mLayout = new QVBoxLayout(this);
    mLayout->addWidget(mScrollArea);

    //Get the pixmap
    auto start = std::chrono::system_clock::now();
    QImage image(imagePath);
    auto end = std::chrono::system_clock::now();
    auto t1 = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
    qDebug()<<"Creating image : "<<t1;

    start = std::chrono::system_clock::now();
    mImageLabel->setPixmap(QPixmap::fromImage(image));
    end = std::chrono::system_clock::now();
    auto t2 = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
    qDebug()<<"Setting pixmap: "<<t2;

    mScrollArea->setWidget(mImageLabel);

    setLayout(mLayout);
    //mImageLabel->setPixmap();
  }
private:
  QScrollArea* mScrollArea;
  QLabel* mImageLabel;
};

ViewerPane::ViewerPane(QWidget * inParent)
:
  QTabWidget(inParent)
  , mTabPages()
{

}

void ViewerPane::RenderFiles(QString const & directory, std::vector<QString> const & fileNames)
{
  // CLose all tabs
//  for(int index=0;index<count();++index)
//  {
//    tabCloseRequested(index);
//  }

  for(auto * widget: mTabPages)
    delete widget;

  for(int index=0;index<count();++index)
    tabCloseRequested(index);

  mTabPages.clear();

  //Render all again
  for(int index=0;index<fileNames.size();++index)
  {
    ImagePage* tabPage = new ImagePage(this,directory+QDir::separator()+fileNames[index]);
    addTab(tabPage,fileNames[index]);
    mTabPages.push_back(tabPage);
  }
}
