#include "MainWindow.h"
#include <QApplication>

#include <thread>

int main(int argc, char *argv[])
{

  std::thread t
  (
    [&]
    {
      QApplication a(argc, argv);
      MainWindow w;
      w.show();
      return a.exec();
    }
  );

  t.join();
  return 0;
}
