#ifndef VIEWERPANE_H
#define VIEWERPANE_H

#include <QString>
#include <QTabWidget>

#include <vector>
class ViewerPane : public QTabWidget
{
public:
  ViewerPane(QWidget * inParent);
  void RenderFiles(QString const & directory, std::vector<QString> const & fileNames);
private:
  std::vector<QWidget*> mTabPages;
};

#endif // VIEWERPANE_H
